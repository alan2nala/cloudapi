$JAVA_HOME/bin/java -classpath .:../lib/cht-paas-hiair-sms-sdk-1.2.jar:../lib/AuthSdk.jar:../lib/gson-1.6.jar cht.paas.hiair.sms.sdk.test.TestSDK
